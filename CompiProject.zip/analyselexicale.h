#ifndef ANALYSELEXICALE_H
#define ANALYSELEXICALE_H

#include <QObject>
#include "myparentobject.h"

class AnalyseLexicale: public MyParentObject
{
public:
    AnalyseLexicale();
    QString analyse(QStringList lines) ;

private:
    void checkDictionary(QString str);
    QMap<QString, QString> language;
};

#endif // ANALYSELEXICALE_H
