#ifndef MYPARENTOBJECT_H
#define MYPARENTOBJECT_H

#include <QObject>
#include <QDebug>

class MyParentObject
{
public:
    MyParentObject();
    bool _isInt(QString str);
    bool _isFloat(QString str);
    bool _isIdentificateur(QString str);
    void _settext(QString str);
    QString console ;


};

#endif // MYPARENTOBJECT_H
