#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QFileDialog>
#include <QDebug>
#include <QStandardPaths>
MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    //this->setWindowTitle("Mon Analyseur Lexical, Syntaxique et Sémantique");
    currentErreur = true;
    ui->textEdit_input->setText("");
    ui->textEdit_input->setVisible(false);
    ui->toolButton_Execute->setVisible(false);
    ui->label_3->setVisible(false);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_toolButton_charger_un_fichier_clicked()
{
    QString filter = "COMPILA file (*.compila)  ;; Text file (*.txt)" ;
    QString defaultpath ;
    QStringList tmp= QStandardPaths::standardLocations(QStandardPaths::DesktopLocation) ;
    //yadini user ta3i
    if(!tmp.isEmpty())
        defaultpath = tmp[0];
    else
        defaultpath = "C:/" ;
    QString fileName = QFileDialog::getOpenFileName(this,"Open a file", defaultpath, filter );
    if(fileName.isEmpty())
        return ;

    //clear local data
    lineList.clear();
    ui->textEdit_console->clear();
    QString line ;
    QFile file(fileName);
    if (file.open(QFile::ReadOnly | QFile::Text))
    {          // yakra ga3e chkyn fel ficheirs
        QTextStream in(&file);
        ui->textEdit_input->setText(in.readAll());

        file.close();
    }
    else
    {
        ui->textEdit_console->setText("Erreur: can't open file "+ file.errorString());
    }
}

void MainWindow::on_toolButton_analyse_lexicale_clicked()
{
//    qDebug() << "start analyse lexicale" ;
//    qDebug() << "lineList: " << lineList;
    reloadText();
    ui->textEdit_console->setText("Analyse Lexicale\n");
    ui->textEdit_console->append(analyseLexicale.analyse(lineList));
    QPalette p = ui->textEdit_console->palette(); // define pallete for textEdit..
    if(ui->textEdit_console->toPlainText().contains(" : erreur <ERR>"))
    {
        p.setColor(QPalette::Base, Qt::red);
        currentErreur = true ;
    }
    else
    {
        p.setColor(QPalette::Base, Qt::blue);
        currentErreur = false ;
    }
    //p.setColor(QPalette::Text, Qt::black);
    ui->textEdit_console->setPalette(p);
//    qDebug() << "end analyse lexicale" ;
}

void MainWindow::on_toolButton_analyse_syntaxique_clicked()
{
    reloadText();
    QString tmp = analyseSyntaxique.analyse(lineList);
    QPalette p = ui->textEdit_console->palette();
    ui->textEdit_console->setText("Analyse Syntaxique\n");
    if( tmp.isEmpty())
    {
        ui->textEdit_console->append("no erreur");
        //p.setColor(QPalette::Base, Qt::green);
        currentErreur = false  ;
    }
    else
    {
        ui->textEdit_console->append(tmp);
        //p.setColor(QPalette::Base, Qt::red);
        currentErreur = true ;
    }
    //p.setColor(QPalette::Text, Qt::black);
    ui->textEdit_console->setPalette(p);
}

void MainWindow::on_toolButton_analyse_semantique_clicked()
{
     // ici los pendejos
    // t3yet l reloadText() ;
    // lineList type QStringList fiha ga3 les lines de text
    // dir boucle line par line dir replace haja b haja
    // almohim ... tnak
    //    //not done yet ...
    QString tmp = analyseSemantique.analyse(lineList);
    QPalette p = ui->textEdit_console->palette();
    ui->textEdit_console->setText("Analyse Semantique\n");
    if( tmp.isEmpty())
    {
        ui->textEdit_console->append("no erreur");
        //p.setColor(QPalette::Base, Qt::green);
        currentErreur = false  ;
    }
    else
    {
        ui->textEdit_console->append(tmp);
        //p.setColor(QPalette::Base, Qt::red);
        currentErreur = true ;
    }
    //p.setColor(QPalette::Text, Qt::black);
    ui->textEdit_console->setPalette(p);
}

void MainWindow::on_toolButton_Execute_clicked()
{
    on_toolButton_analyse_lexicale_clicked();
    if(currentErreur) return ;
    on_toolButton_analyse_syntaxique_clicked();
    if(currentErreur) return ;
    on_toolButton_analyse_semantique_clicked();
    if(currentErreur) return ;

    reloadText();
    //QString tmp = analyseSemantique.execute(lineList);
    //QPalette p = ui->textEdit_console->palette();


    //ui->textEdit_console->setText(tmp);
    //p.setColor(QPalette::Base, Qt::black);
    //p.setColor(QPalette::Text, Qt::white);

    //ui->textEdit_console->setPalette(p);
}

void MainWindow::reloadText()
{

    QStringList tmpList = ui->textEdit_input->toPlainText().split("\n");
    QString line ;
    lineList.clear();
    for ( int i = 0 ; i < tmpList.length() ; i++ )
    {
        line = tmpList[i] ;
        if(line.contains("//."))
            continue ;
        line.replace("  ", " ");
        line.replace(",", " , ");
        line.replace("\"", " \" ");
        line.replace("  ", " ");
        //The first changes all of your whitespace characters
        // to a single instance of ASCII 32, the second removes that.
        // url: https://stackoverflow.com/questions/8256190/removing-whitespaces-inside-a-string
        // supp all espace
        line = line.simplified();
        //line.replace( " ", "" );

        lineList << line ;


    }
}

