#include "analyselexicale.h"

AnalyseLexicale::AnalyseLexicale()
{ // instarsion dans la liste
    language.insert("Start_Program"," : Mot réservé début d'un programme");
    language.insert("End_Program"," : Mot réservé fin d'un programme");
    language.insert("Int_Number"," : Mot réservé déclaration d'un entie");
    language.insert("Real_Number"," : Mot réservé déclaration d'un réel");
    language.insert("ShowMes"," : Mot réservé");
    language.insert("ShowVal"," : Mot réservé");
    language.insert("Start"," : Mot réservé");
    language.insert("Finnish"," : Mot réservé");
    language.insert("If"," : Mot réservé");
    language.insert("Else"," : Mot réservé");
    language.insert("--"," : Mot réservé pour une condition");
    language.insert("\""," : caractere réserve pour chaine de caracter");
    language.insert("//."," : Mot réservé pour commentaire");
    language.insert("<"," : symbole inferieur");
    language.insert("Give"," : Mot réservé");
    language.insert("Affect"," : Mot réservé");
    language.insert(";;"," : Mot réservé");
    language.insert("to"," : Mot réservé");
    language.insert(":"," : caractere réserve");
    language.insert(","," : caractere réserve");

}

QString AnalyseLexicale::analyse(QStringList lines)
{
    console.clear();
    // veux meux utilis foreach blast for bech matatkhaletch f les index i j u
    int msg_detected = 0 ;
    QString tmp ;
    for ( int i = 0 ; i < lines.length() ; i++ )
    {
        msg_detected = 0 ;
        QString line = lines[i] ;
        line.replace("<"," < ");
        line.replace(">"," > ");
        line.replace("="," = ");
        line.replace("  "," ");
        QStringList words = line.split(" ");
        for ( int j = 0 ; j < words.length() ; j++ )
        {
            QString word = words[j] ;
         //   qDebug() << word ;
            //this is stupid kont kader ndirha foug boucle j pour l'optimisation
            if( word.isEmpty())
                continue ; // continue if word is empty
            if( word.contains("//."))
                continue ; // exception pour line commentaire
            //exception
            //detection d'un message
            if( word == "\"" && msg_detected == 0)
            {
                msg_detected = 1 ;
                tmp += "\"" ;
                continue ;
            }
            if( word == "\"" && msg_detected == 1)
                msg_detected = 2 ;
            if(msg_detected == 1 )
            {
                tmp += word+" " ;
                continue ;
            }

            if(msg_detected == 2 )
            {
                tmp += "\"" ;
                _settext(tmp+" : Affichage d'un message a l'ecran");
                tmp.clear();
                msg_detected=0;
                continue ;
            }

            if(!language.value(word).isEmpty())
                console += word + language.value(word) +"\n" ;
            else
            {
                if( _isIdentificateur(word))
                    _settext(word+" : identificateur");
                else if( _isInt(word))
                    _settext(word+" : Valeur entiere");
                else if( _isFloat(word))
                    _settext(word+" : Valeur flotante");
                else
                    _settext(word+" : erreur <ERR> dans la line "+QString::number(i+1));
            }


        }
    }

    return console ;
}

