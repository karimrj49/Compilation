#include "analysesemantique.h"

AnalyseSemantique::AnalyseSemantique()
{

}


QString AnalyseSemantique::analyse(QStringList lines)
{
    console.clear();
    ram.clear();
    for ( int i = 0 ; i < lines.length() ; i++ )
    {
        QString line = lines[i] ;
        QStringList words = line.split(" ");
        QString word = words[0] ;

        if( word.isEmpty())
            continue ;
        if( word.contains("//."))
            continue ; // exception pour line commentaire

        if(word == "Int_Number" || word == "Real_Number")
            if(Declaration(words)) continue ;

        if(word == "Give" || word == "Affect")
            if(Affectation(words)) continue ;

        if(word == "ShowVal")
            if(Affichage(words)) continue ;

        if( word == "Else")
            continue ;

        if( word == "Start_Program" || word == "End_Program"
                || word == "Start" || word == "Finish" || word == "ShowMes" )
            continue ;
        if( words[0] == "If" && words[1] == "--" && words[3] == "--" && Condition(words[2]))
        {


            QString tmp01;
            for ( int j = 4 ; j < words.length() ; j++)
            {
                if( j < words.length()-1)
                    tmp01 += words[j] + " " ;
                else
                    tmp01 += words[j] ;
            }
            lines[i] = tmp01 ;
            i = i -1 ;
            qDebug() << "words " << words << tmp01 ;
            continue;
        }

        console += line +" erreur dans la line " + QString::number(i+1) + "\n";


    }


    return console;
}

bool AnalyseSemantique::Declaration(QStringList words)
{
    for ( int i = 2 ; i < words.length() -1 ; i++ )
    {
        if(words[i] == ",")
            continue ;

        variable tmp ;
        if(words[0] == "Int_Number" )
            tmp.type = "int" ;
        else if(words[0] == "Real_Number" )
            tmp.type = "float" ;
        else return false ; // machi int machi float donc erreur
        // pour evite double declaration
        if(findThisIdentificateur(words[i]) > -1)
            // idaaa  routournet foug -1 alors sa existe
            return false ;
// ici ajoutite f la ram
        tmp.identificateur = words[i] ;

        ram << tmp ;
    }

    return true ;
}


bool AnalyseSemantique::Affectation(QStringList words)
{ //verification bark
    if(words[0] == "Give")
    {
        for (int i = 0 ; i < ram.length() ; i++ )
        {
            //qDebug() << ram[i].type +" "+ ram[i].identificateur +" "+ ram[i].value ;
            if(ram[i].identificateur == words[1])
            {
                if(ram[i].type == "int" && _isInt(words[3]))
                {
                    ram[i].value = words[3] ;
                    return true ;
                }
                else if(ram[i].type == "float" && _isFloat(words[3]))
                {
                    ram[i].value = words[3] ;
                    return true ;
                }
                else return false ;
            }
        }
        console += words[1] + " not found\n";
        return false ;
    }
    if(words[0] == "Affect")
    {    // je dois verifier si ils sont deja declaer
        int x,y ;
        x = findThisIdentificateur(words[1]);
        y = findThisIdentificateur(words[3]);
        // idaa tahte 0 sa! pas
        if( x < 0 || y < 0)
            return false ;
        // dois avoir le meme type
        if(ram[x].type != ram[y].type )
            return false ;
        ram[y].value = ram[x].value;
        return true ;
    }
    return false ; // to avoid waring msg
}


bool AnalyseSemantique::Affichage(QStringList words)
{ // idaa ident  sa existe pas return false
    int index = findThisIdentificateur(words[2]);
    if(index < 0)
        return false ;
    return true ;
}

bool AnalyseSemantique::Condition(QString word)
{
    QStringList tmp ;
    if(word.contains("<") )
        tmp = word.split("<");

    if(word.contains(">") )
        tmp = word.split(">");

    if(word.contains("=") )
        tmp = word.split("=");

    if(tmp.length() != 2 )
        return false;

    int x = findThisIdentificateur(tmp[0]) ;
    int y = findThisIdentificateur(tmp[1]) ;
    if( x < 0 || y < 0 )
        return false ;
    if(ram[x].value.isEmpty())
        return false ;
    if(ram[y].value.isEmpty())
        return false ;


    return true ;
}

int AnalyseSemantique::findThisIdentificateur(QString name)
{ // ida existe dans la ram et je re declare alors erreur
    int index = -1 ;
    for (int i = 0 ; i < ram.length() ; i++)
    {
        if(ram[i].identificateur == name)
        {
            index = i ;
            break;
        }
    }
    return index ;
}

