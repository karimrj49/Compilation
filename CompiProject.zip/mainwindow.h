#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "analyselexicale.h"
#include "analysesyntaxique.h"
#include "analysesemantique.h"

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    void reloadText();
private slots:
    void on_toolButton_charger_un_fichier_clicked();

    void on_toolButton_analyse_lexicale_clicked();

    void on_toolButton_analyse_syntaxique_clicked();

    void on_toolButton_analyse_semantique_clicked();

    void on_toolButton_Execute_clicked();

private:
    Ui::MainWindow *ui;
    QStringList lineList ;
    AnalyseLexicale analyseLexicale;
    AnalyseSyntaxique analyseSyntaxique;
    AnalyseSemantique analyseSemantique;
    bool currentErreur ;

};

#endif // MAINWINDOW_H
