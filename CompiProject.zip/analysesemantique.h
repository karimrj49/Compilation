#ifndef ANALYSESEMANTIQUE_H
#define ANALYSESEMANTIQUE_H

#include <QObject>
#include "myparentobject.h"

// var c est une structure
struct variable{
    QString type;
    QString identificateur ;
    QString value ;
};
class AnalyseSemantique: public MyParentObject
{
public:
    AnalyseSemantique();
    QString analyse(QStringList lines) ;

    bool Declaration(QStringList words);
    bool Affectation(QStringList words);
    bool Affichage(QStringList words);
    int findThisIdentificateur(QString name);
    bool Condition(QString word);
    QString execute(QStringList lines);
    bool Condition2(QString word);
//derna liste ta3e structure
private:
    QList<variable> ram ;
};

#endif // ANALYSESEMANTIQUE_H
