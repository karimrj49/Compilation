#include "analysesyntaxique.h"

AnalyseSyntaxique::AnalyseSyntaxique()
{

}

QString AnalyseSyntaxique::analyse(QStringList lines)
{
    //declaration ( int_number, real,number )
    //affectation ( give, affect )
    //affichage ( showmsg, showval )
    //condition ( if, else, start, finnish ) pas besion f analyse syntaxique
    console.clear();
    // veux meux utilis foreach blast for bech matatkhaletch f les index i j u
    QStringList pile ;
    int dejaEXsite = -1 ;
    // parcour all lignes
    for ( int i = 0 ; i < lines.length() ; i++ )
    {
                // iciydir split line by line
                // la ligne de i n7atha  f line
        QString line = lines[i] ;
        // kyn espace je split
        QStringList words = line.split(" ");
        // nerfed kalma lewla
        QString word = words[0] ;
             // incremante i
        if( word.isEmpty())
            continue ;
        if( word.contains("//."))
            continue ; // exception pour line commentaire

        if(word == "Int_Number" || word == "Real_Number")
            if(isDeclaration(words)) continue ;

        if(word == "Give" || word == "Affect")
            if(isAffectation(words)) continue ;

        if(word == "ShowMes" || word == "ShowVal")
            if(isAffichage(words)) continue ;
            // je dois trouver dejaexite = i pour tester idaaa se trouve if avant else
        if(word == "If")
            dejaEXsite = i ;
        if( word == "Else")
        {
            if(dejaEXsite == -1)
                console += "If not found erreur dans la line " + QString::number(i) + "\n";
            else
                dejaEXsite = -1 ;
            continue ;
        }
        if( word == "Start_Program" || word == "End_Program"
                || word == "Start" || word == "Finish"  )
        {
            pile << word ;
            continue ;
        }

        if( words[0] == "If" && words[1] == "--" && words[3] == "--" && isCondition(words[2]))
        {
            QString tmp01;
            for ( int j = 4 ; j < words.length() ; j++)
            {
                if( j < words.length()-1)
                    tmp01 += words[j] + " " ;
                else
                    tmp01 += words[j] ;
            }
            lines[i] = tmp01 ;
            i = i -1 ;

            qDebug() << "words " << words << tmp01 ;
            continue;
        }
        qDebug() << "word " << word ;
        console += line +" erreur dans la line " + QString::number(i+1) + "\n";
//            break; // break c'est optional

    }

 // pile 1 start  pile 2 end
    QStringList pile1 , pile2 ;
    QString tmpMSG ;
    bool erreur = false ;
    for ( int i = 0 ; i < pile.length() ; i++ )
    {
        QString word = pile[i];
        tmpMSG += word + " " ;
        if( word == "Start_Program" || word == "Start" )
            pile1 << word ;

        if( word == "End_Program")
        {
            if(!pile1.contains("Start_Program"))
                erreur = true ;
            pile2 << word ;
        }
        if( word == "Finish")
        {
            if(!pile1.contains("Start"))
                erreur = true ;
            pile2 << word ;
        }
        if(pile1.isEmpty() || pile2.isEmpty())
            continue;
        if(pile1[pile1.length()-1] == "Start_Program" &&
                pile2[0] == "End_Program")
        {
            pile1.removeLast();
            pile2.removeFirst();
            if(!pile1.isEmpty() && !pile2.isEmpty())
            {
                console += "erreur dans la pile: "+ tmpMSG + "\n" ;
                return console ;
            }
        }
        else if(pile1[pile1.length()-1] == "Start" &&
                pile2[0] == "Finish")
        {
            pile1.removeLast();
            pile2.removeFirst();
        }

    }
    if(!pile1.isEmpty() && !pile2.isEmpty())
        console += "erreur dans la pile: "+ tmpMSG + "\n" ;
    if(erreur)
        console += "erreur dans la pile: "+ tmpMSG + "\n" ;
    return console ;
}

bool AnalyseSyntaxique::isDeclaration(QStringList words)
{     //ylik ykune tahte 4
    if( words.length() < 4 )
        return false ;
    if(words[1] != ":")
        return false ;
        // je parcour mel kelma 3 hata nruh
    for ( int i = 2 ; i < words.length() -1 ; i++ )
    {
         if(_isIdentificateur(words[i]) || words[i] == ",")
             continue;
         else
             return false ;
    }
    if(words[words.length()-1] != ";;")
        return false ;
    return true ;
}

bool AnalyseSyntaxique::isAffectation(QStringList words)
{
    qDebug() << "bool AnalyseSyntaxique::isAffectation(QStringList words): " << words;
    //protiction contre overflow index
    if( words.length() != 5 )
        return false ;

    if(!_isIdentificateur(words[1]))
        return false ;

    //Give i : 23 ;;
    if (words[0] == "Give" && words[2] == ":" && words[4] == ";;")
        if(_isFloat(words[3]) || _isInt(words[3]) )
            return true ;

    //Affect i to j ;;
    if (words[0] == "Affect" && words[2] == "to" && words[4] == ";;")
        if(_isIdentificateur(words[3]) )
            return true ;
    return false ; // return false de tout facon
}

bool AnalyseSyntaxique::isAffichage(QStringList words)
{
    //qDebug() << "bool AnalyseSyntaxique::isAffichage(QStringList words): " << words;
    if( words[0] == "ShowVal" )
        if (words.length() != 4)
            return false ;
        else{
            if( words[1] == ":" && _isIdentificateur(words[2]) && words[3] == ";;")
                return true ;
            else
                return false ;
        }
    else
    {
        if( words[1] == ":" && words[2] == "\"" && words[words.length()-2] == "\"" && words[words.length()-1] == ";;")
            return true ;
        else
            return false ;
    }
}

bool AnalyseSyntaxique::isCondition(QString word)
{
    QStringList tmp ;
    if(word.contains("<") )
        tmp = word.split("<");

    if(word.contains(">") )
        tmp = word.split(">");

    if(word.contains("=") )
        tmp = word.split("=");

    if(tmp.length() != 2 )
        return false;

    if( _isIdentificateur(tmp[0]) && _isIdentificateur(tmp[1]) )
        return true;

    return false ;
}
