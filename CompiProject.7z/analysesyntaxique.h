#ifndef ANALYSESYNTAXIQUE_H
#define ANALYSESYNTAXIQUE_H

#include <QObject>
#include "myparentobject.h"
class AnalyseSyntaxique: public MyParentObject
{
public:
    AnalyseSyntaxique();
    QString analyse(QStringList lines) ;
private:
    bool isDeclaration(QStringList words);
    bool isAffectation(QStringList words);
    bool isAffichage(QStringList words);
    bool isCondition(QString word);

};

#endif // ANALYSESYNTAXIQUE_H
