#ifndef ANALYSELEXICALE_H
#define ANALYSELEXICALE_H

#include <QObject>
#include "myparentobject.h"

class AnalyseLexicale: public MyParentObject
{
public:
    AnalyseLexicale();
    QString analyse(QStringList lines) ;

private:
    QMap<QString, QString> language;
  void checkDictionary(QString str);
};

#endif // ANALYSELEXICALE_H
